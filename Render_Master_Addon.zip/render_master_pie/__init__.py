# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Render Master Pie",
    "author" : "Robinswrld", 
    "description" : "short cut LEFT Ctrl + LEFT Alt . to access the import and export pie, LFT_Ctrl + LFT_Shift ",
    "blender" : (3, 0, 0),
    "version" : (1, 2, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
class SNA_MT_6D45A(bpy.types.Menu):
    bl_idname = "SNA_MT_6D45A"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('import_scene.fbx', text='FBX', icon_value=0, emboss=True, depress=False)
        op = layout.operator('import_scene.obj', text='OBJ', icon_value=0, emboss=True, depress=False)
        box_FED56 = layout.box()
        box_FED56.alert = False
        box_FED56.enabled = True
        box_FED56.active = True
        box_FED56.use_property_split = False
        box_FED56.use_property_decorate = False
        box_FED56.alignment = 'Expand'.upper()
        box_FED56.scale_x = 1.869999885559082
        box_FED56.scale_y = 1.0
        box_FED56.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_FED56.label(text='Export', icon_value=0)
        col_EFFCD = box_FED56.column(heading='Export', align=False)
        col_EFFCD.alert = False
        col_EFFCD.enabled = True
        col_EFFCD.active = True
        col_EFFCD.use_property_split = False
        col_EFFCD.use_property_decorate = False
        col_EFFCD.scale_x = 1.0
        col_EFFCD.scale_y = 1.0
        col_EFFCD.alignment = 'Expand'.upper()
        col_EFFCD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_EFFCD.operator('export_scene.obj', text='OBJ', icon_value=0, emboss=True, depress=False)
        op = col_EFFCD.operator('export_scene.fbx', text='FBX', icon_value=0, emboss=True, depress=False)
        op = layout.operator('wm.append', text='Append', icon_value=0, emboss=True, depress=False)
        op = layout.operator('import_image.to_plane', text='Image as plane', icon_value=0, emboss=True, depress=False)


class SNA_MT_26853(bpy.types.Menu):
    bl_idname = "SNA_MT_26853"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('sna.import_formats_df7b3', text='IMPORT', icon_value=706, emboss=True, depress=False)
        op = layout.operator('sna.export_format_a61f8', text='EXPORT', icon_value=707, emboss=True, depress=False)


class SNA_OT_Import_Formats_Df7B3(bpy.types.Operator):
    bl_idname = "sna.import_formats_df7b3"
    bl_label = "Import Formats"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        col_E3E7E = layout.column(heading='Format', align=False)
        col_E3E7E.alert = False
        col_E3E7E.enabled = True
        col_E3E7E.active = True
        col_E3E7E.use_property_split = False
        col_E3E7E.use_property_decorate = False
        col_E3E7E.scale_x = 1.0
        col_E3E7E.scale_y = 1.0
        col_E3E7E.alignment = 'Right'.upper()
        col_E3E7E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_E3E7E.operator('import_scene.obj', text='OBJ', icon_value=0, emboss=True, depress=False)
        op = col_E3E7E.operator('import_scene.fbx', text='FBX', icon_value=0, emboss=True, depress=False)
        op = col_E3E7E.operator('import_image.to_plane', text='Image as plane', icon_value=0, emboss=True, depress=False)
        op = col_E3E7E.operator('export_scene.gltf', text='gLTF', icon_value=0, emboss=True, depress=False)
        op = col_E3E7E.operator('wm.append', text='Append', icon_value=0, emboss=True, depress=False)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Export_Format_A61F8(bpy.types.Operator):
    bl_idname = "sna.export_format_a61f8"
    bl_label = "Export Format"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        col_52C26 = layout.column(heading='', align=False)
        col_52C26.alert = False
        col_52C26.enabled = True
        col_52C26.active = True
        col_52C26.use_property_split = False
        col_52C26.use_property_decorate = False
        col_52C26.scale_x = 1.0
        col_52C26.scale_y = 1.0
        col_52C26.alignment = 'Expand'.upper()
        col_52C26.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_52C26.operator('export_scene.obj', text='OBJ', icon_value=0, emboss=True, depress=False)
        op = col_52C26.operator('export_scene.fbx', text='FBX', icon_value=0, emboss=True, depress=False)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Aspect__Ratio_D7Fad(bpy.types.Operator):
    bl_idname = "sna.aspect__ratio_d7fad"
    bl_label = "Aspect  ratio"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'].render, 'resolution_x', text='', icon_value=0, emboss=True)
        layout.prop(bpy.data.scenes['Scene'].render, 'resolution_y', text='', icon_value=0, emboss=True)
        layout.prop(bpy.data.scenes['Scene'].cycles, 'samples', text='Samples', icon_value=2, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_MT_B8884(bpy.types.Menu):
    bl_idname = "SNA_MT_B8884"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('sna.mode_f0063', text='Renderer', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.devices_59a6f', text='Rendering Device', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.aspect__ratio_03220', text='Aspect Ratio', icon_value=0, emboss=True, depress=False)


class SNA_OT_Mode_647Fc(bpy.types.Operator):
    bl_idname = "sna.mode_647fc"
    bl_label = "Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'].render, 'engine', text='', icon_value=0, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Devices_6Ad42(bpy.types.Operator):
    bl_idname = "sna.devices_6ad42"
    bl_label = "Devices"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'].cycles, 'device', text='', icon_value=0, emboss=True)
        layout.prop(bpy.data.scenes['Scene'].cycles, 'use_preview_denoising', text='Denoise', icon_value=0, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_View_Render_95653(bpy.types.Operator):
    bl_idname = "sna.view_render_95653"
    bl_label = "view render"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.render.view_show('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_Cd23D(bpy.types.Operator):
    bl_idname = "sna.operator_cd23d"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.render.play_rendered_anim('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_D1F83(bpy.types.Menu):
    bl_idname = "SNA_MT_D1F83"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('sna.mode_f0063', text='Renderer', icon_value=83, emboss=True, depress=False)
        op = layout.operator('sna.operator_cd23d', text='View Animation', icon_value=777, emboss=True, depress=False)
        op = layout.operator('sna.aspect__ratio_03220', text='Aspect Ratio', icon_value=27, emboss=True, depress=False)
        op = layout.operator('sna.render_image_f56d5', text='Render Image', icon_value=258, emboss=True, depress=False)
        op = layout.operator('sna.render_animation_1c99b', text='Render Animation', icon_value=191, emboss=True, depress=False)
        op = layout.operator('sna.view_render_95653', text='View Render', icon_value=755, emboss=True, depress=False)
        op = layout.operator('sna.devices_59a6f', text='Rendering Device', icon_value=23, emboss=True, depress=False)
        op = layout.operator('sna.format_40627', text='output', icon_value=84, emboss=True, depress=False)


class SNA_OT_Mode_F0063(bpy.types.Operator):
    bl_idname = "sna.mode_f0063"
    bl_label = "Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'].render, 'engine', text='', icon_value=0, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Devices_59A6F(bpy.types.Operator):
    bl_idname = "sna.devices_59a6f"
    bl_label = "Devices"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'].cycles, 'device', text='', icon_value=0, emboss=True, toggle=True)
        row_9120D = layout.row(heading='', align=False)
        row_9120D.alert = False
        row_9120D.enabled = True
        row_9120D.active = True
        row_9120D.use_property_split = False
        row_9120D.use_property_decorate = False
        row_9120D.scale_x = 1.0
        row_9120D.scale_y = 1.0
        row_9120D.alignment = 'Expand'.upper()
        row_9120D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_9120D.separator(factor=1.0899999141693115)
        col_C0DF2 = row_9120D.column(heading='Viewport Denoise', align=False)
        col_C0DF2.alert = False
        col_C0DF2.enabled = True
        col_C0DF2.active = True
        col_C0DF2.use_property_split = False
        col_C0DF2.use_property_decorate = False
        col_C0DF2.scale_x = 1.0
        col_C0DF2.scale_y = 1.0
        col_C0DF2.alignment = 'Expand'.upper()
        col_C0DF2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_C0DF2.prop(bpy.data.scenes['Scene'].cycles, 'use_preview_denoising', text='Denoise', icon_value=0, emboss=True)
        row_9120D.separator(factor=1.0899999141693115)
        col_BFFD6 = row_9120D.column(heading='Color Management', align=False)
        col_BFFD6.alert = False
        col_BFFD6.enabled = True
        col_BFFD6.active = True
        col_BFFD6.use_property_split = False
        col_BFFD6.use_property_decorate = False
        col_BFFD6.scale_x = 1.0
        col_BFFD6.scale_y = 1.0
        col_BFFD6.alignment = 'Expand'.upper()
        col_BFFD6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_BFFD6.prop(bpy.data.scenes['Scene'].view_settings, 'view_transform', text='', icon_value=54, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Render_Image_F56D5(bpy.types.Operator):
    bl_idname = "sna.render_image_f56d5"
    bl_label = "Render Image"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.render.render('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Render_Animation_1C99B(bpy.types.Operator):
    bl_idname = "sna.render_animation_1c99b"
    bl_label = "Render Animation"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.render.render('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Aspect__Ratio_03220(bpy.types.Operator):
    bl_idname = "sna.aspect__ratio_03220"
    bl_label = "Aspect  ratio"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'].render, 'resolution_x', text='', icon_value=0, emboss=True)
        layout.prop(bpy.data.scenes['Scene'].render, 'resolution_y', text='', icon_value=0, emboss=True)
        col_95709 = layout.column(heading='Render Samples', align=False)
        col_95709.alert = False
        col_95709.enabled = True
        col_95709.active = True
        col_95709.use_property_split = False
        col_95709.use_property_decorate = False
        col_95709.scale_x = 1.0
        col_95709.scale_y = 1.0
        col_95709.alignment = 'Expand'.upper()
        col_95709.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_95709.prop(bpy.data.scenes['Scene'].cycles, 'samples', text='Samples', icon_value=2, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Format_40627(bpy.types.Operator):
    bl_idname = "sna.format_40627"
    bl_label = "Format"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'].render, 'filepath', text='', icon_value=0, emboss=True)
        layout.prop(bpy.data.scenes['Scene'].render.image_settings, 'file_format', text='', icon_value=0, emboss=True)
        layout.separator(factor=1.0899999141693115)
        col_A44AA = layout.column(heading='Image sequence', align=False)
        col_A44AA.alert = False
        col_A44AA.enabled = True
        col_A44AA.active = True
        col_A44AA.use_property_split = False
        col_A44AA.use_property_decorate = True
        col_A44AA.scale_x = 1.0
        col_A44AA.scale_y = 1.0
        col_A44AA.alignment = 'Expand'.upper()
        col_A44AA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_A44AA.prop(bpy.data.scenes['Scene'].render, 'use_overwrite', text='Overwrite', icon_value=0, emboss=True)
        layout.separator(factor=0.6400003433227539)
        layout.label(text='Film management', icon_value=0)
        row_E2F3E = layout.row(heading='', align=False)
        row_E2F3E.alert = False
        row_E2F3E.enabled = True
        row_E2F3E.active = True
        row_E2F3E.use_property_split = False
        row_E2F3E.use_property_decorate = False
        row_E2F3E.scale_x = 1.0
        row_E2F3E.scale_y = 1.0
        row_E2F3E.alignment = 'Expand'.upper()
        row_E2F3E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_E2F3E.prop(bpy.data.scenes['Scene'].render, 'film_transparent', text='Transparent', icon_value=0, emboss=True)
        row_E2F3E.prop(bpy.data.scenes['Scene'].cycles, 'film_transparent_glass', text='Transparent Glass', icon_value=0, emboss=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_MT_6D45A)
    bpy.utils.register_class(SNA_MT_26853)
    bpy.utils.register_class(SNA_OT_Import_Formats_Df7B3)
    bpy.utils.register_class(SNA_OT_Export_Format_A61F8)
    bpy.utils.register_class(SNA_OT_Aspect__Ratio_D7Fad)
    bpy.utils.register_class(SNA_MT_B8884)
    bpy.utils.register_class(SNA_OT_Mode_647Fc)
    bpy.utils.register_class(SNA_OT_Devices_6Ad42)
    bpy.utils.register_class(SNA_OT_View_Render_95653)
    bpy.utils.register_class(SNA_OT_Operator_Cd23D)
    bpy.utils.register_class(SNA_MT_D1F83)
    bpy.utils.register_class(SNA_OT_Mode_F0063)
    bpy.utils.register_class(SNA_OT_Devices_59A6F)
    bpy.utils.register_class(SNA_OT_Render_Image_F56D5)
    bpy.utils.register_class(SNA_OT_Render_Animation_1C99B)
    bpy.utils.register_class(SNA_OT_Aspect__Ratio_03220)
    bpy.utils.register_class(SNA_OT_Format_40627)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'LEFT_SHIFT', 'PRESS',
        ctrl=True, alt=False, shift=False, repeat=False)
    kmi.properties.name = 'SNA_MT_26853'
    addon_keymaps['1B78A'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'LEFT_ALT', 'PRESS',
        ctrl=True, alt=False, shift=False, repeat=False)
    kmi.properties.name = 'SNA_MT_D1F83'
    addon_keymaps['980DB'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_MT_6D45A)
    bpy.utils.unregister_class(SNA_MT_26853)
    bpy.utils.unregister_class(SNA_OT_Import_Formats_Df7B3)
    bpy.utils.unregister_class(SNA_OT_Export_Format_A61F8)
    bpy.utils.unregister_class(SNA_OT_Aspect__Ratio_D7Fad)
    bpy.utils.unregister_class(SNA_MT_B8884)
    bpy.utils.unregister_class(SNA_OT_Mode_647Fc)
    bpy.utils.unregister_class(SNA_OT_Devices_6Ad42)
    bpy.utils.unregister_class(SNA_OT_View_Render_95653)
    bpy.utils.unregister_class(SNA_OT_Operator_Cd23D)
    bpy.utils.unregister_class(SNA_MT_D1F83)
    bpy.utils.unregister_class(SNA_OT_Mode_F0063)
    bpy.utils.unregister_class(SNA_OT_Devices_59A6F)
    bpy.utils.unregister_class(SNA_OT_Render_Image_F56D5)
    bpy.utils.unregister_class(SNA_OT_Render_Animation_1C99B)
    bpy.utils.unregister_class(SNA_OT_Aspect__Ratio_03220)
    bpy.utils.unregister_class(SNA_OT_Format_40627)
